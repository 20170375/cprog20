#include <stdio.h>

typedef unsigned char *pointer;

void show_bytes(pointer start, size_t len){
    int result=0, num=*(int*)start;
    for(size_t i=0; i<len; i++){
        printf("%p\t0x%.2x\n",start+i,start[i]);
	result = result*16*16 + start[len-1-i];
    }
    if(result == num){ printf("Little-Endian\n\n"); }
    else{ printf("Big-Endian\n\n"); }
}

void show_arch(){
    printf("sizeof(char)\t: %ld bytes\n",sizeof(char));
    printf("sizeof(short)\t: %ld bytes\n",sizeof(short));
    printf("sizeof(int)\t: %ld bytes\n",sizeof(int));
    printf("sizeof(long)\t: %ld bytes\n",sizeof(long));
    printf("sizeof(pointer)\t: %ld bytes\n",sizeof(pointer));
    if(sizeof(long)==8 && sizeof(pointer)==8){
        printf("64-bit system.\n");
    } else{
        printf("32-bit system.\n");
    }
}

int main(){
    int a = 15213;
    printf("int a = 15213;\n");
    show_bytes((pointer) &a, sizeof(int));
    show_arch();
    return 0;
}
